# Build Manager Bot 🤖

Convert Flutter project ZIP files to APK with a Telegram Bot powered by Node.js!

## Features ✨

- 📱 **Convert ZIP to APK** via Flutter
- 🤖 **Telegram Bot Interface** dengan button UI
- ⏳ **Queue System** - Build antri satu-satu
- 📊 **Live Progress Monitoring** - Monitor build progress real-time
- 💳 **Credit System** - 5 credit per user, +5 setiap minggu
- 🔗 **VPS Integration** - SSH connection ke VPS untuk build
- 📦 **Auto Dependencies Installation** - Install semua dependency otomatis
- 👑 **Owner Menu** - Manage VPS, users, dan credits
- 💾 **SQLite Database** - Simple & reliable

## Tech Stack 🛠️

- **Runtime:** Node.js v21
- **Bot Framework:** Telegraf
- **Database:** SQLite3
- **Build Tool:** Flutter SDK
- **VPS Connection:** SSH (node-ssh)
- **Process Manager:** PM2

## Requirements 📋

### VPS Requirements
- Node.js v21
- Java OpenJDK 17
- Android SDK 36.0.0
- Flutter SDK Stable
- CMake 3.22.1
- NDK 27.0.12077973
- PM2 Process Manager
- Local Telegram Bot API (optional)

### Local Requirements
- Node.js v21+
- npm atau yarn

## Installation 🚀

### 1. Clone Repository
```bash
git clone <repository-url>
cd build-manager-bot