#!/bin/bash

# Build Manager Bot - Dependency Installation Script
# Run this script on your VPS to install all required dependencies

echo "🚀 Build Manager Bot - Dependency Installation"
echo "================================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo -e "${RED}❌ This script must be run as root${NC}"
  exit 1
fi

# Update system
echo -e "${YELLOW}📦 Updating system packages...${NC}"
apt-get update && apt-get upgrade -y

# Install Node.js 21
echo -e "${YELLOW}📦 Installing Node.js v21...${NC}"
curl -fsSL https://deb.nodesource.com/setup_21.x | bash -
apt-get install -y nodejs

# Verify Node.js
node --version
npm --version

# Install Java OpenJDK 17
echo -e "${YELLOW}📦 Installing Java OpenJDK 17...${NC}"
apt-get install -y openjdk-17-jdk

# Verify Java
java -version

# Install build tools
echo -e "${YELLOW}📦 Installing build tools...${NC}"
apt-get install -y build-essential git wget unzip curl

# Install CMake
echo -e "${YELLOW}📦 Installing CMake...${NC}"
apt-get install -y cmake

# Verify CMake
cmake --version

# Create directories
mkdir -p /opt/flutter
mkdir -p /opt/android-sdk
mkdir -p /opt/android-ndk

# Install Flutter SDK
echo -e "${YELLOW}📦 Installing Flutter SDK (Stable)...${NC}"
cd /opt/flutter || exit
git clone https://github.com/flutter/flutter.git -b stable .

# Add Flutter to PATH
export PATH="/opt/flutter/bin:$PATH"
echo 'export PATH="/opt/flutter/bin:$PATH"' >> /etc/profile.d/flutter.sh

# Configure Flutter
flutter config --no-analytics

# Install Android SDK Platform Tools
echo -e "${YELLOW}📦 Installing Android SDK Platform Tools...${NC}"
apt-get install -y android-sdk-platform-tools

# Set ANDROID_SDK_ROOT
export ANDROID_SDK_ROOT=/opt/android-sdk
echo 'export ANDROID_SDK_ROOT=/opt/android-sdk' >> /etc/profile.d/android-sdk.sh

# Install NDK 27.0.12077973
echo -e "${YELLOW}📦 Installing Android NDK r27...${NC}"
cd /opt/android-ndk || exit
wget https://dl.google.com/android/repository/android-ndk-r27-linux.zip
unzip -q android-ndk-r27-linux.zip
rm android-ndk-r27-linux.zip

# Set NDK PATH
export ANDROID_NDK_ROOT=/opt/android-ndk/android-ndk-r27
echo 'export ANDROID_NDK_ROOT=/opt/android-ndk/android-ndk-r27' >> /etc/profile.d/android-ndk.sh

# Install PM2 globally
echo -e "${YELLOW}📦 Installing PM2 Process Manager...${NC}"
npm install -g pm2

# Verify PM2
pm2 --version

# Run Flutter precache and doctor
echo -e "${YELLOW}📦 Running Flutter precache...${NC}"
flutter precache

echo -e "${YELLOW}📦 Running Flutter doctor...${NC}"
flutter doctor

# Summary
echo ""
echo -e "${GREEN}✅ Installation Complete!${NC}"
echo ""
echo "Installed versions:"
echo "- Node.js: $(node --version)"
echo "- npm: $(npm --version)"
echo "- Java: $(java -version 2>&1 | head -n 1)"
echo "- CMake: $(cmake --version | head -n 1)"
echo "- PM2: $(pm2 --version)"
echo ""
echo -e "${YELLOW}📝 Next steps:${NC}"
echo "1. Copy your bot project to /home/container/build-manager-bot"
echo "2. Configure config.js with your Bot Token and Owner ID"
echo "3. Run: npm install"
echo "4. Run: npm start or pm2 start index.js --name 'build-manager-bot'"
echo ""
echo -e "${GREEN}🎉 Ready to build some APKs!${NC}"
