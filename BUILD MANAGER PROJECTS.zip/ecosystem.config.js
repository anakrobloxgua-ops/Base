module.exports = {
  apps: [
    {
      name: "build-manager-bot",
      script: "./index.js",
      instances: 1,
      exec_mode: "cluster",
      env: {
        NODE_ENV: "production",
      },
      error_file: "./logs/err.log",
      out_file: "./logs/out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      merge_logs: true,
      watch: false,
      max_memory_restart: "1G",
      ignore_watch: ["node_modules", "database", "logs"],
      max_restarts: 10,
      min_uptime: "10s",
      autorestart: true,
      // Graceful reload
      kill_timeout: 5000,
      wait_ready: true,
      listen_timeout: 10000,
    },
  ],

  deploy: {
    production: {
      user: "root",
      host: "YOUR_VPS_IP",
      ref: "origin/main",
      repo: "git@github.com:YOUR_REPO.git",
      path: "/home/container/build-manager-bot",
      "post-deploy":
        "npm install && pm2 restart build-manager-bot --update-env",
      "pre-deploy-local": "echo 'Deploying to production...'",
    },
  },
};
