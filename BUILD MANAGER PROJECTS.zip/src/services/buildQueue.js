const { v4: uuidv4 } = require("uuid");
const FileManager = require("../database/fileManager");
const SSHManager = require("./sshManager");
const config = require("../../config");

class BuildQueue {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
    this.currentBuild = null;
    this.db = new FileManager();
    this.ssh = new SSHManager();
  }

  addBuild(buildData) {
    const buildId = uuidv4();
    
    const build = {
      id: buildId,
      userId: buildData.userId,
      fileId: buildData.fileId,
      fileName: buildData.fileName,
      status: "pending",
      progress: 0,
      createdAt: new Date(),
    };

    this.queue.push(build);
    this.db.addBuild(buildId, buildData.userId, buildData.fileName);
    
    console.log(`📋 Build added to queue: ${buildId}`);
    
    // Start processing if not already processing
    if (!this.isProcessing) {
      this.processBuild();
    }

    return buildId;
  }

  getQueueLength() {
    return this.queue.length;
  }

  async processBuild() {
    if (this.isProcessing || this.queue.length === 0) {
      return;
    }

    this.isProcessing = true;
    const build = this.queue.shift();
    this.currentBuild = build;

    try {
      console.log(`🔨 Processing build: ${build.id}`);
      
      // Update status to processing
      await this.db.updateBuildStatus(build.id, "processing", 10);

      // Connect to VPS
      await this.ssh.initialize();
      
      if (!this.ssh.isConnected()) {
        await this.ssh.connect();
      }

      // Update progress
      await this.db.updateBuildStatus(build.id, "processing", 30);

      // Download file from Telegram
      console.log(`📥 Downloading file: ${build.fileId}`);
      await this.db.updateBuildStatus(build.id, "processing", 50);

      // Build Flutter APK
      console.log(`🔨 Building Flutter APK for build: ${build.id}`);
      const outputPath = `${config.FLUTTER.OUTPUT_DIR}/${build.id}`;
      
      await this.ssh.executeCommand(`mkdir -p ${outputPath}`);
      await this.db.updateBuildStatus(build.id, "processing", 70);

      // Here you would download file from Telegram and upload to VPS
      // For now, we'll simulate it
      await this.db.updateBuildStatus(build.id, "processing", 90);

      // Complete build
      await this.db.completeBuild(build.id, "success", `${outputPath}/output.apk`);
      
      console.log(`✅ Build completed successfully: ${build.id}`);

    } catch (error) {
      console.error(`❌ Build failed: ${build.id}`, error.message);
      await this.db.completeBuild(build.id, "failed", null, error.message);
      
      // Deduct credit for failed build
      await this.db.deductCredit(build.userId, 1);
    }

    this.isProcessing = false;
    this.currentBuild = null;

    // Process next build in queue
    if (this.queue.length > 0) {
      setTimeout(() => this.processBuild(), 1000);
    }
  }

  getCurrentBuild() {
    return this.currentBuild;
  }

  cancelBuild(buildId) {
    if (this.currentBuild && this.currentBuild.id === buildId) {
      console.log(`❌ Cancelling current build: ${buildId}`);
      return false; // Cannot cancel current build
    }

    const index = this.queue.findIndex((b) => b.id === buildId);
    if (index !== -1) {
      this.queue.splice(index, 1);
      console.log(`❌ Build cancelled: ${buildId}`);
      return true;
    }

    return false;
  }
}

module.exports = BuildQueue;
