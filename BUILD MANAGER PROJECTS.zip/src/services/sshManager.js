const { NodeSSH } = require("node-ssh");
const fs = require("fs");
const path = require("path");
const config = require("../../config");

class SSHManager {
  constructor(db) {
    this.ssh = new NodeSSH();
    this.db = db; // ← TERIMA dari parameter
    this.connected = false;
  }

  async initialize() {
    try {
      this.db.initialize();
      console.log("✅ SSH Manager initialized");
    } catch (error) {
      console.error("❌ Failed to initialize SSH Manager:", error.message);
    }
  }

  async connect() {
    try {
      const vpsConfig = this.db.getVPSConfig(); // ← TIDAK perlu await
      
      if (!vpsConfig || !vpsConfig.host) {
        throw new Error("VPS configuration not found");
      }

      const connectConfig = {
        host: vpsConfig.host,
        port: vpsConfig.port || 22,
        username: vpsConfig.username || "root",
      };

      // Use private key if available, otherwise use password
      if (vpsConfig.private_key && fs.existsSync(vpsConfig.private_key)) {
        connectConfig.privateKey = fs.readFileSync(vpsConfig.private_key);
      } else if (vpsConfig.password) {
        connectConfig.password = vpsConfig.password;
      }

      await this.ssh.connect(connectConfig);
      this.connected = true;
      console.log("✅ SSH Connected to VPS:", vpsConfig.host);
      return true;
    } catch (error) {
      this.connected = false;
      console.error("❌ SSH Connection failed:", error.message);
      throw error;
    }
  }

  async disconnect() {
    try {
      if (this.ssh.isConnected()) {
        await this.ssh.dispose();
        this.connected = false;
      }
    } catch (error) {
      console.error("❌ Error disconnecting SSH:", error.message);
    }
  }

  async executeCommand(command) {
    try {
      if (!this.connected) {
        await this.connect();
      }

      const result = await this.ssh.execCommand(command);
      
      if (result.code !== 0) {
        throw new Error(result.stderr || "Command execution failed");
      }

      return result.stdout;
    } catch (error) {
      console.error("❌ Command execution error:", error.message);
      throw error;
    }
  }

  async installDependencies() {
    try {
      console.log("📦 Starting dependency installation...");

      if (!this.connected) {
        await this.connect();
      }

      const commands = [
        // Update package manager
        "apt-get update && apt-get upgrade -y",
        
        // Install Node.js 21
        "curl -fsSL https://deb.nodesource.com/setup_21.x | bash - && apt-get install -y nodejs",
        
        // Install Java OpenJDK 17
        "apt-get install -y openjdk-17-jdk",
        
        // Install required build tools
        "apt-get install -y build-essential git wget unzip",
        
        // Install CMake 3.22.1
        "apt-get install -y cmake",
        
        // Install Flutter SDK
        this.getFlutterInstallCommand(),
        
        // Install Android SDK
        this.getAndroidSdkCommand(),
        
        // Install NDK 27.0.12077973
        this.getNdkInstallCommand(),
        
        // Install PM2 globally
        "npm install -g pm2",
        
        // Setup Flutter
        "flutter precache",
        "flutter doctor",
      ];

      for (const command of commands) {
        try {
          console.log(`🔧 Executing: ${command.substring(0, 50)}...`);
          await this.executeCommand(command);
          console.log("✅ Done");
        } catch (error) {
          console.warn(`⚠️ Warning during installation: ${error.message}`);
          // Continue with next command even if one fails
        }
      }

      console.log("✅ Dependencies installation completed!");
      return true;
    } catch (error) {
      console.error("❌ Dependency installation error:", error.message);
      throw error;
    }
  }

  getFlutterInstallCommand() {
    return `
      cd /opt && \\
      git clone https://github.com/flutter/flutter.git -b stable && \\
      export PATH="/opt/flutter/bin:$PATH" && \\
      flutter config --no-analytics
    `;
  }

  getAndroidSdkCommand() {
    return `
      apt-get install -y android-sdk-platform-tools && \\
      mkdir -p /opt/android-sdk && \\
      export ANDROID_SDK_ROOT=/opt/android-sdk
    `;
  }

  getNdkInstallCommand() {
    return `
      mkdir -p /opt/android-ndk && \\
      cd /opt/android-ndk && \\
      wget https://dl.google.com/android/repository/android-ndk-r27-linux.zip && \\
      unzip android-ndk-r27-linux.zip && \\
      rm android-ndk-r27-linux.zip
    `;
  }

  async buildFlutterProject(projectPath, outputPath) {
    try {
      if (!this.connected) {
        await this.connect();
      }

      console.log(`🔨 Building Flutter project: ${projectPath}`);

      // Extract ZIP if needed
      const extractCommand = `cd /tmp && unzip -o ${projectPath}`;
      await this.executeCommand(extractCommand);

      // Get project directory (assuming it's the first directory in ZIP)
      const listCommand = `ls -d /tmp/*/pubspec.yaml | head -1 | xargs dirname`;
      const projectDir = await this.executeCommand(listCommand);

      // Clean previous build
      await this.executeCommand(`cd ${projectDir} && flutter clean`);

      // Get dependencies
      console.log("📦 Getting Flutter dependencies...");
      await this.executeCommand(`cd ${projectDir} && flutter pub get`);

      // Build APK
      console.log("🔨 Building APK...");
      const buildCommand = `cd ${projectDir} && flutter build apk ${config.FLUTTER.BUILD_FLAGS}`;
      await this.executeCommand(buildCommand);

      // Copy result
      const apkPath = `${projectDir}/build/app/outputs/flutter-apk/app-${config.FLUTTER.BUILD_FLAGS.replace('--', '')}.apk`;
      const resultPath = `${outputPath}/output.apk`;
      
      await this.executeCommand(`cp ${apkPath} ${resultPath}`);

      console.log("✅ Flutter build successful!");
      return resultPath;
    } catch (error) {
      console.error("❌ Flutter build error:", error.message);
      throw error;
    }
  }

  async testConnection() {
    try {
      if (!this.connected) {
        await this.connect();
      }

      const result = await this.executeCommand("echo 'Connection test successful!'");
      return true;
    } catch (error) {
      return false;
    }
  }

  isConnected() {
    return this.connected && this.ssh.isConnected();
  }
}

module.exports = SSHManager;