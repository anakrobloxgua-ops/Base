const fs = require("fs");
const path = require("path");

class FileManager {
  constructor() {
    this.dbPath = path.join(__dirname);
    this.creditsFile = path.join(this.dbPath, "credits.json");
    this.historyFile = path.join(this.dbPath, "history.json");
    this.vpsFile = path.join(this.dbPath, "vps.json");

    this.initializeFiles();
  }

  initializeFiles() {
    // Create credits.json if not exists
    if (!fs.existsSync(this.creditsFile)) {
      fs.writeFileSync(
        this.creditsFile,
        JSON.stringify({ users: {} }, null, 2)
      );
      console.log("✅ Created: credits.json");
    }

    // Create history.json if not exists
    if (!fs.existsSync(this.historyFile)) {
      fs.writeFileSync(
        this.historyFile,
        JSON.stringify({ builds: [] }, null, 2)
      );
      console.log("✅ Created: history.json");
    }

    // Create vps.json if not exists
    if (!fs.existsSync(this.vpsFile)) {
      fs.writeFileSync(
        this.vpsFile,
        JSON.stringify(
          {
            vps: {
              host: null,
              port: 22,
              username: "root",
              password: null,
              private_key: null,
              updated_at: null
            }
          },
          null,
          2
        )
      );
      console.log("✅ Created: vps.json");
    }

    console.log("✅ All database files initialized");
  }

  // ===== READ =====

  readCredits() {
    try {
      const data = fs.readFileSync(this.creditsFile, "utf8");
      return JSON.parse(data);
    } catch (error) {
      console.error("❌ Error reading credits.json:", error);
      return { users: {} };
    }
  }

  readHistory() {
    try {
      const data = fs.readFileSync(this.historyFile, "utf8");
      return JSON.parse(data);
    } catch (error) {
      console.error("❌ Error reading history.json:", error);
      return { builds: [] };
    }
  }

  readVPS() {
    try {
      const data = fs.readFileSync(this.vpsFile, "utf8");
      return JSON.parse(data);
    } catch (error) {
      console.error("❌ Error reading vps.json:", error);
      return {
        vps: {
          host: null,
          port: 22,
          username: "root",
          password: null,
          private_key: null,
          updated_at: null
        }
      };
    }
  }

  // ===== WRITE =====

  writeCredits(data) {
    try {
      fs.writeFileSync(this.creditsFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error("❌ Error writing credits.json:", error);
    }
  }

  writeHistory(data) {
    try {
      fs.writeFileSync(this.historyFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error("❌ Error writing history.json:", error);
    }
  }

  writeVPS(data) {
    try {
      fs.writeFileSync(this.vpsFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error("❌ Error writing vps.json:", error);
    }
  }

  // ===== USER METHODS (CREDITS) =====

  addUser(telegramId, name) {
    const credits = this.readCredits();
    if (!credits.users[telegramId]) {
      credits.users[telegramId] = {
        id: telegramId,
        name: name,
        credit: 5,
        last_credit_update: new Date().toISOString(),
        created_at: new Date().toISOString()
      };
      this.writeCredits(credits);
      console.log(`✅ User added: ${telegramId}`);
    }
  }

  getUserData(telegramId) {
    const credits = this.readCredits();
    return credits.users[telegramId] || null;
  }

  addCredit(telegramId, amount) {
    const credits = this.readCredits();
    if (credits.users[telegramId]) {
      credits.users[telegramId].credit += amount;
      this.writeCredits(credits);
      console.log(`✅ Credit added: ${telegramId} +${amount}`);
    }
  }

  deductCredit(telegramId, amount) {
    const credits = this.readCredits();
    if (credits.users[telegramId]) {
      credits.users[telegramId].credit = Math.max(
        0,
        credits.users[telegramId].credit - amount
      );
      this.writeCredits(credits);
      console.log(`✅ Credit deducted: ${telegramId} -${amount}`);
    }
  }

  setCredit(telegramId, amount) {
    const credits = this.readCredits();
    if (credits.users[telegramId]) {
      credits.users[telegramId].credit = amount;
      this.writeCredits(credits);
      console.log(`✅ Credit set: ${telegramId} = ${amount}`);
    }
  }

  // ===== BUILD METHODS (HISTORY) =====

  addBuild(telegramId, buildId, fileName) {
    const history = this.readHistory();
    history.builds.push({
      id: history.builds.length + 1,
      build_id: buildId,
      telegram_id: telegramId,
      file_name: fileName,
      status: "pending",
      progress: 0,
      result: null,
      created_at: new Date().toISOString()
    });
    this.writeHistory(history);
    console.log(`✅ Build added: ${buildId}`);
    return buildId;
  }

  updateBuildStatus(buildId, status, progress = 0) {
    const history = this.readHistory();
    const build = history.builds.find(b => b.build_id === buildId);
    if (build) {
      build.status = status;
      build.progress = progress;
      this.writeHistory(history);
      console.log(`✅ Build updated: ${buildId} -> ${status}`);
    }
  }

  updateBuildProgress(buildId, progress) {
    const history = this.readHistory();
    const build = history.builds.find(b => b.build_id === buildId);
    if (build) {
      build.progress = progress;
      this.writeHistory(history);
    }
  }

  completeBuild(buildId, status, result) {
    const history = this.readHistory();
    const build = history.builds.find(b => b.build_id === buildId);
    if (build) {
      build.status = status;
      build.result = result;
      this.writeHistory(history);
      console.log(`✅ Build completed: ${buildId} -> ${status}`);
    }
  }

  getBuild(buildId) {
    const history = this.readHistory();
    return history.builds.find(b => b.build_id === buildId) || null;
  }

  getUserBuilds(telegramId, limit = 10) {
    const history = this.readHistory();
    return history.builds
      .filter(b => b.telegram_id === telegramId)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, limit);
  }

  // ===== VPS METHODS (VPS CONFIG) =====

  getVPSConfig() {
    const vpsData = this.readVPS();
    return vpsData.vps;
  }

  setVPSConfig(host, port = 22, username = "root", password = null, privateKey = null) {
    const vpsData = this.readVPS();
    vpsData.vps = {
      host: host,
      port: port,
      username: username,
      password: password,
      private_key: privateKey,
      updated_at: new Date().toISOString()
    };
    this.writeVPS(vpsData);
    console.log(`✅ VPS config saved: ${host}:${port}`);
  }

  deleteVPSConfig() {
    const vpsData = this.readVPS();
    vpsData.vps = {
      host: null,
      port: 22,
      username: "root",
      password: null,
      private_key: null,
      updated_at: null
    };
    this.writeVPS(vpsData);
    console.log("✅ VPS config deleted");
  }

  // ===== BOT STATS =====

  getBotStats() {
    const credits = this.readCredits();
    const history = this.readHistory();

    return {
      total_users: Object.keys(credits.users).length,
      total_builds: history.builds.length,
      success_builds: history.builds.filter(b => b.status === "success").length,
      failed_builds: history.builds.filter(b => b.status === "failed").length
    };
  }

  // ===== INITIALIZE =====

  initialize() {
    console.log("✅ Database initialized (JSON Files)");
  }
}

module.exports = FileManager;