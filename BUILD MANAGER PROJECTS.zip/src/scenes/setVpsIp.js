const { WizardScene } = require("telegraf/scenes");
const FileManager = require("../database/fileManager");

const db = new FileManager();

const setVpsIp = new WizardScene(
  "setVpsIp",
  (ctx) => {
    ctx.reply("🔧 **Set VPS Configuration**\n\nSilakan kirimkan IP address VPS Anda:\n_(Contoh: 192.168.1.1)_", {
      parse_mode: "Markdown",
    });

    return ctx.wizard.next();
  },
  async (ctx) => {
    const ip = ctx.message.text;

    // Validate IP
    if (!this.isValidIP(ip)) {
      ctx.reply("❌ Format IP tidak valid! Silakan coba lagi.");
      return;
    }

    ctx.session.vpsIp = ip;

    ctx.reply(
      `✅ IP VPS: ${ip}\n\n` +
      "Sekarang kirimkan PORT SSH (default: 22):",
      { parse_mode: "Markdown" }
    );

    return ctx.wizard.next();
  },
  async (ctx) => {
    const port = ctx.message.text;

    if (isNaN(port) || port < 1 || port > 65535) {
      ctx.reply("❌ Port tidak valid! (1-65535)");
      return;
    }

    ctx.session.vpsPort = parseInt(port);

    ctx.reply("Kirimkan USERNAME SSH (default: root):");
    return ctx.wizard.next();
  },
  async (ctx) => {
    const username = ctx.message.text || "root";
    ctx.session.vpsUsername = username;

    ctx.reply("Kirimkan PASSWORD SSH (atau 'skip' jika menggunakan key):");
    return ctx.wizard.next();
  },
  async (ctx) => {
    const password = ctx.message.text === "skip" ? null : ctx.message.text;
    ctx.session.vpsPassword = password;

    try {
      db.initialize();
      
      await db.setVPSConfig(
        ctx.session.vpsIp,
        ctx.session.vpsPort,
        ctx.session.vpsUsername,
        ctx.session.vpsPassword
      );

      ctx.reply(
        "✅ **VPS Configuration Saved!**\n\n" +
        `Host: ${ctx.session.vpsIp}\n` +
        `Port: ${ctx.session.vpsPort}\n` +
        `Username: ${ctx.session.vpsUsername}\n\n` +
        "Silakan jalankan /depenssh untuk install dependencies.",
        { parse_mode: "Markdown" }
      );

    } catch (error) {
      ctx.reply(`❌ Error: ${error.message}`);
    }

    return ctx.scene.leave();
  }
);

setVpsIp.isValidIP = function (ip) {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (!ipRegex.test(ip)) return false;

  const parts = ip.split(".");
  return parts.every((part) => parseInt(part) >= 0 && parseInt(part) <= 255);
};

module.exports = setVpsIp;
