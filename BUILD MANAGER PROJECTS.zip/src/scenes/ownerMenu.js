const { Markup } = require("telegraf");
const { WizardScene } = require("telegraf/scenes");

const ownerMenu = new WizardScene(
  "ownerMenu",
  (ctx) => {
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback("🔧 Set VPS IP", "set_vps_ip")],
      [Markup.button.callback("🔄 Reconnect VPS", "reconnect_vps")],
      [Markup.button.callback("📦 Install Dependencies", "install_deps")],
      [Markup.button.callback("📊 Bot Stats", "bot_stats")],
      [Markup.button.callback("🔙 Back", "back_main")],
    ]);

    ctx.reply("👑 **Owner Menu**\n\nPilih aksi:", {
      parse_mode: "Markdown",
      reply_markup: buttons.reply_markup,
    });

    return ctx.wizard.next();
  }
);

module.exports = ownerMenu;
