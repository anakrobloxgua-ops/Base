// ===== CONFIG BUILD MANAGER BOT =====

module.exports = {
  // Bot Configuration
  BOT_TOKEN: "8994820309:AAGPLcnYePmre0KruF7BXoGfdBwH5V8v1Qs", // Ganti dengan bot token dari @BotFather
  OWNER_ID: 1842733815, // Owner Telegram ID
  
  // VPS Configuration
  VPS: {
    HOST: null, // Akan di-set via owner menu
    PORT: 22,
    USERNAME: "root", // Atau sesuaikan dengan user VPS Anda
    PASSWORD: null, // Bisa pake password atau private key
    PRIVATE_KEY: null, // Path ke private key jika menggunakan SSH key
  },
  
  // Database
  DATABASE: {
    PATH: "./database/buildmanager.db",
    TIMEOUT: 5000,
  },
  
  // Build Configuration
  BUILD: {
    TIMEOUT: 3600000, // 1 jam timeout per build
    MAX_QUEUE: 100,
    CREDIT_DEFAULT: 5,
    CREDIT_WEEKLY_ADD: 5,
  },
  
  // Flutter Build
  FLUTTER: {
    BUILD_TYPE: "apk", // apk, aab, atau keduanya
    BUILD_FLAGS: "--release", // --debug atau --release
    OUTPUT_DIR: "/tmp/flutter_builds",
  },
  
  // Local Telegram Bot API
  LOCAL_API: {
    ENABLED: false, // Set true jika menggunakan Local Telegram Bot API
    SERVER: "http://localhost:8081",
  },

  // Dependencies Installation
  DEPENDENCIES: [
    "nodejs:21",
    "openjdk-17-jdk",
    "android-sdk",
    "flutter-sdk",
    "cmake:3.22.1",
    "ndk:27.0.12077973",
    "pm2",
  ],
};