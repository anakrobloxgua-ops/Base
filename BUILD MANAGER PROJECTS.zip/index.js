const { Telegraf, Markup } = require("telegraf");
const FileManager = require("./src/database/fileManager");
const SSHManager = require("./src/services/sshManager");
const BuildQueue = require("./src/services/buildQueue");
const config = require("./config");

// Initialize
const bot = new Telegraf(config.BOT_TOKEN);
const db = new FileManager();
const ssh = new SSHManager();
const queue = new BuildQueue();

let isInstallingDependencies = false;
let userSessions = {}; // Simple session storage

// ===== STARTUP =====
const startBot = async () => {
  try {
    console.log("🚀 Starting Build Manager Bot...");
    
    // Initialize Database
    db.initialize();
    console.log("✅ Database initialized");
    
    // Initialize SSH Connection
    await ssh.initialize();
    console.log("✅ SSH Manager initialized");
    
    // Check if VPS is configured
    const vpsConfig = await db.getVPSConfig();
    if (!vpsConfig || !vpsConfig.host) {
      console.log("⚠️ VPS NOT CONFIGURED");
      console.log("📝 Owner dapat set VPS IP via /owner menu");
    } else {
      console.log("✅ VPS configured:", vpsConfig.host);
      
      // Auto-install dependencies on startup
      isInstallingDependencies = true;
      console.log("📦 Starting auto-install dependencies...");
      
      try {
        await ssh.installDependencies();
        console.log("✅ Dependencies installed successfully");
        isInstallingDependencies = false;
      } catch (error) {
        console.error("❌ Failed to install dependencies:", error.message);
        isInstallingDependencies = false;
      }
    }
    
    // Start Bot
    bot.launch();
    console.log("✅ Bot started successfully!");
    
  } catch (error) {
    console.error("❌ Failed to start bot:", error);
    process.exit(1);
  }
};

// ===== MIDDLEWARE =====

// Check if installing dependencies
bot.use((ctx, next) => {
  if (isInstallingDependencies) {
    ctx.reply("⚠️ Sedang Tahap Install Depenciens, Mohon Tunggu Sebentar.");
    return;
  }
  return next();
});

// Check VPS Connection - HANYA untuk build-related commands
bot.use(async (ctx, next) => {
  const vpsConfig = await db.getVPSConfig();
  
  // List command/action yang butuh VPS
  const needsVPS = [
    "build_apk",
    "/depenssh",
    "install_deps",
    "reconnect_vps",
  ];
  
  const checkIfNeedsVPS = 
    (ctx.message?.text && needsVPS.some(cmd => ctx.message.text.includes(cmd))) ||
    (ctx.callbackQuery?.data && needsVPS.includes(ctx.callbackQuery.data));
  
  if (checkIfNeedsVPS && (!vpsConfig || !vpsConfig.host)) {
    if (ctx.callbackQuery) {
      ctx.answerCbQuery("⚠️ VPS belum diset! Set via /owner menu", true);
    } else {
      ctx.reply("⚠️ SSH Not Connect, Tidak Bisa Build Sementara Waktu");
    }
    return;
  }
  
  return next();
});

// ===== COMMANDS =====

// /start Command
bot.command("start", async (ctx) => {
  const userId = ctx.from.id;
  
  try {
    // Initialize user if not exists
    let user = await db.getUserData(userId);
    if (!user) {
      await db.addUser(userId, ctx.from.first_name || "User");
      user = await db.getUserData(userId);
    }
    
    const vpsConfig = await db.getVPSConfig();
    
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback("📱 Build APK", "build_apk")],
      [Markup.button.callback("📊 My Builds", "my_builds")],
      [Markup.button.callback("💳 Credit", "check_credit")],
      [Markup.button.callback("ℹ️ Help", "help")],
    ]);
    
    if (ctx.from.id === config.OWNER_ID) {
      buttons.reply_markup.inline_keyboard.push([
        Markup.button.callback("👑 Owner Menu", "owner_menu"),
      ]);
    }
    
    let message = 
      `Halo ${user.name}! 👋\n\n` +
      `Selamat datang di **Build Manager Bot**\n\n` +
      `Konversi file ZIP ke APK dengan mudah menggunakan Flutter!\n\n` +
      `💳 Credit Anda: ${user.credit}/5\n` +
      `📦 Build Queue: ${queue.getQueueLength()}/100`;
    
    if (!vpsConfig || !vpsConfig.host) {
      message += `\n\n⚠️ **VPS belum dikonfigurasi!**\n_Owner bisa set IP via menu Owner_`;
    } else {
      message += `\n\n✅ **VPS Connected:** ${vpsConfig.host}`;
    }
    
    ctx.reply(message, {
      parse_mode: "Markdown",
      reply_markup: buttons.reply_markup,
    });
  } catch (error) {
    console.error("Error in /start:", error);
    ctx.reply("❌ Error saat memproses data");
  }
});

// /help Command
bot.command("help", (ctx) => {
  ctx.reply(
    "📚 **Bantuan Build Manager Bot**\n\n" +
    "**Fitur Utama:**\n" +
    "• 📱 Build APK dari file ZIP Flutter project\n" +
    "• 💳 Sistem kredit (5 credit per minggu)\n" +
    "• ⏳ Queue system (antri jika sedang build)\n" +
    "• 📊 Monitor progress build real-time\n\n" +
    "**Commands:**\n" +
    "/start - Mulai bot\n" +
    "/help - Bantuan\n" +
    "/credit - Cek credit\n" +
    "/builds - Riwayat build\n" +
    "/depenssh - Install dependencies (Owner)\n\n" +
    "**Owner Commands:**\n" +
    "/owner - Menu owner\n" +
    "/addcredit <ID> <JUMLAH> - Tambah credit\n" +
    "/delcredit <ID> <JUMLAH> - Kurangi credit\n" +
    "/resetcredit <ID> - Reset credit ke 0\n\n" +
    "Silakan gunakan tombol di bawah untuk navigasi! 👇",
    {
      parse_mode: "Markdown",
    }
  );
});

// /credit Command
bot.command("credit", async (ctx) => {
  try {
    const user = await db.getUserData(ctx.from.id);
    if (!user) {
      ctx.reply("❌ User data tidak ditemukan");
      return;
    }
    
    ctx.reply(
      `💳 **Kredit Anda**\n\n` +
      `Current: ${user.credit}/5\n` +
      `Last Update: ${new Date(user.last_credit_update).toLocaleString()}\n\n` +
      `_Credit akan otomatis ditambah 5 setiap minggu_`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error in /credit:", error);
    ctx.reply("❌ Error mengambil data credit");
  }
});

// /builds Command
bot.command("builds", async (ctx) => {
  try {
    const userId = ctx.from.id;
    const builds = await db.getUserBuilds(userId);
    
    if (!builds || builds.length === 0) {
      ctx.reply("📭 Anda belum pernah melakukan build.");
      return;
    }
    
    let message = "📊 **Riwayat Build Anda:**\n\n";
    builds.forEach((build, index) => {
      message += `${index + 1}. Status: ${build.status}\n`;
      message += `   Tanggal: ${new Date(build.created_at).toLocaleString()}\n\n`;
    });
    
    ctx.reply(message, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("Error in /builds:", error);
    ctx.reply("❌ Error mengambil data build");
  }
});

// /owner Command
bot.command("owner", (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.reply("❌ Anda tidak memiliki akses ke menu owner!");
    return;
  }
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback("🔧 Set VPS IP", "set_vps_ip")],
    [Markup.button.callback("🔄 Reconnect VPS", "reconnect_vps")],
    [Markup.button.callback("📦 Install Dependencies", "install_deps")],
    [Markup.button.callback("📊 Bot Stats", "bot_stats")],
    [Markup.button.callback("👥 User Management", "user_management")],
  ]);
  
  ctx.reply("👑 **Owner Menu**\n\nPilih aksi:", {
    parse_mode: "Markdown",
    reply_markup: buttons.reply_markup,
  });
});

// /addcredit Command
bot.command("addcredit", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.reply("❌ Hanya owner yang bisa menjalankan command ini!");
    return;
  }
  
  const args = ctx.message.text.split(" ");
  if (args.length < 3) {
    ctx.reply("/addcredit <USER_ID> <JUMLAH>");
    return;
  }
  
  const userId = parseInt(args[1]);
  const amount = parseInt(args[2]);
  
  if (isNaN(userId) || isNaN(amount)) {
    ctx.reply("❌ User ID dan Jumlah harus berupa angka!");
    return;
  }
  
  try {
    const user = await db.getUserData(userId);
    if (!user) {
      ctx.reply("❌ User tidak ditemukan!");
      return;
    }
    
    await db.addCredit(userId, amount);
    const updatedUser = await db.getUserData(userId);
    ctx.reply(
      `✅ Credit ditambahkan!\n\n` +
      `User: ${user.name} (${userId})\n` +
      `Tambah: +${amount}\n` +
      `Credit Sekarang: ${updatedUser.credit}`
    );
  } catch (error) {
    console.error("Error in /addcredit:", error);
    ctx.reply("❌ Error saat menambah credit");
  }
});

// /delcredit Command
bot.command("delcredit", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.reply("❌ Hanya owner yang bisa menjalankan command ini!");
    return;
  }
  
  const args = ctx.message.text.split(" ");
  if (args.length < 3) {
    ctx.reply("/delcredit <USER_ID> <JUMLAH>");
    return;
  }
  
  const userId = parseInt(args[1]);
  const amount = parseInt(args[2]);
  
  if (isNaN(userId) || isNaN(amount)) {
    ctx.reply("❌ User ID dan Jumlah harus berupa angka!");
    return;
  }
  
  try {
    const user = await db.getUserData(userId);
    if (!user) {
      ctx.reply("❌ User tidak ditemukan!");
      return;
    }
    
    await db.deductCredit(userId, amount);
    const updatedUser = await db.getUserData(userId);
    ctx.reply(
      `✅ Credit dikurangi!\n\n` +
      `User: ${user.name} (${userId})\n` +
      `Kurangi: -${amount}\n` +
      `Credit Sekarang: ${updatedUser.credit}`
    );
  } catch (error) {
    console.error("Error in /delcredit:", error);
    ctx.reply("❌ Error saat mengurangi credit");
  }
});

// /resetcredit Command
bot.command("resetcredit", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.reply("❌ Hanya owner yang bisa menjalankan command ini!");
    return;
  }
  
  const args = ctx.message.text.split(" ");
  if (args.length < 2) {
    ctx.reply("/resetcredit <USER_ID>");
    return;
  }
  
  const userId = parseInt(args[1]);
  if (isNaN(userId)) {
    ctx.reply("❌ User ID harus berupa angka!");
    return;
  }
  
  try {
    const user = await db.getUserData(userId);
    if (!user) {
      ctx.reply("❌ User tidak ditemukan!");
      return;
    }
    
    await db.setCredit(userId, 0);
    ctx.reply(
      `✅ Credit di-reset!\n\n` +
      `User: ${user.name} (${userId})\n` +
      `Credit: 0`
    );
  } catch (error) {
    console.error("Error in /resetcredit:", error);
    ctx.reply("❌ Error saat reset credit");
  }
});

// /depenssh Command
bot.command("depenssh", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.reply("❌ Hanya owner yang bisa menjalankan command ini!");
    return;
  }
  
  try {
    const vpsConfig = await db.getVPSConfig();
    if (!vpsConfig || !vpsConfig.host) {
      ctx.reply("❌ VPS belum dikonfigurasi!");
      return;
    }
    
    ctx.reply("📦 Sedang install dependencies... Mohon tunggu.");
    
    isInstallingDependencies = true;
    await ssh.installDependencies();
    isInstallingDependencies = false;
    ctx.reply("✅ Dependencies berhasil diinstall!");
  } catch (error) {
    isInstallingDependencies = false;
    console.error("Error in /depenssh:", error);
    ctx.reply(`❌ Gagal install dependencies:\n${error.message}`);
  }
});

// ===== CALLBACKS =====

// Build APK Callback
bot.action("build_apk", (ctx) => {
  ctx.reply(
    "📱 **Build APK**\n\n" +
    "Silakan upload file ZIP yang berisi Flutter project Anda.\n\n" +
    "_Format: .zip containing pubspec.yaml_",
    {
      parse_mode: "Markdown",
    }
  );
  
  ctx.answerCbQuery();
});

// My Builds Callback
bot.action("my_builds", async (ctx) => {
  try {
    const userId = ctx.from.id;
    const builds = await db.getUserBuilds(userId);
    
    if (!builds || builds.length === 0) {
      ctx.reply("📭 Anda belum pernah melakukan build.");
      ctx.answerCbQuery();
      return;
    }
    
    let message = "📊 **Riwayat Build Anda:**\n\n";
    builds.forEach((build, index) => {
      message += `${index + 1}. Status: ${build.status}\n`;
      message += `   Tanggal: ${new Date(build.created_at).toLocaleString()}\n\n`;
    });
    
    ctx.reply(message, { parse_mode: "Markdown" });
    ctx.answerCbQuery();
  } catch (error) {
    console.error("Error in my_builds callback:", error);
    ctx.reply("❌ Error mengambil riwayat build");
    ctx.answerCbQuery();
  }
});

// Check Credit Callback
bot.action("check_credit", async (ctx) => {
  try {
    const user = await db.getUserData(ctx.from.id);
    if (!user) {
      ctx.reply("❌ User data tidak ditemukan");
      ctx.answerCbQuery();
      return;
    }
    
    ctx.reply(
      `💳 **Kredit Anda**\n\n` +
      `Current: ${user.credit}/5\n` +
      `Last Update: ${new Date(user.last_credit_update).toLocaleString()}\n\n` +
      `_Credit akan otomatis ditambah 5 setiap minggu_`,
      {
        parse_mode: "Markdown",
      }
    );
    ctx.answerCbQuery();
  } catch (error) {
    console.error("Error in check_credit callback:", error);
    ctx.reply("❌ Error mengambil data credit");
    ctx.answerCbQuery();
  }
});

// Help Callback
bot.action("help", (ctx) => {
  ctx.reply(
    "📚 **Bantuan Build Manager Bot**\n\n" +
    "Gunakan command:\n" +
    "/help - untuk informasi lengkap",
    {
      parse_mode: "Markdown",
    }
  );
  ctx.answerCbQuery();
});

// Owner Menu Callback
bot.action("owner_menu", (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback("🔧 Set VPS IP", "set_vps_ip")],
    [Markup.button.callback("🔄 Reconnect VPS", "reconnect_vps")],
    [Markup.button.callback("📦 Install Dependencies", "install_deps")],
    [Markup.button.callback("📊 Bot Stats", "bot_stats")],
    [Markup.button.callback("👥 User Management", "user_management")],
  ]);
  
  ctx.reply("👑 **Owner Menu**\n\nPilih aksi:", {
    parse_mode: "Markdown",
    reply_markup: buttons.reply_markup,
  });
  
  ctx.answerCbQuery();
});

// Set VPS IP Callback
bot.action("set_vps_ip", (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  ctx.reply(
    "🔧 **Set VPS IP**\n\n" +
    "Silakan kirimkan IP address VPS Anda:\n" +
    "_(Contoh: 192.168.1.1 atau domain.com)_",
    {
      parse_mode: "Markdown",
    }
  );
  
  // Set session untuk user ini
  userSessions[ctx.from.id] = { awaitingVpsIp: true };
  
  ctx.answerCbQuery();
});

// Reconnect VPS Callback
bot.action("reconnect_vps", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  ctx.reply("🔄 Sedang reconnect ke VPS...");
  
  try {
    const vpsConfig = await db.getVPSConfig();
    if (!vpsConfig || !vpsConfig.host) {
      ctx.reply("❌ VPS belum dikonfigurasi!");
      ctx.answerCbQuery();
      return;
    }
    
    await ssh.connect();
    ctx.reply(`✅ Reconnect berhasil ke VPS: ${vpsConfig.host}`);
  } catch (error) {
    console.error("Error in reconnect_vps:", error);
    ctx.reply(`❌ Gagal reconnect ke VPS:\n${error.message}`);
  }
  
  ctx.answerCbQuery();
});

// Install Dependencies Callback
bot.action("install_deps", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  ctx.reply("📦 Sedang install dependencies...");
  
  try {
    isInstallingDependencies = true;
    await ssh.installDependencies();
    isInstallingDependencies = false;
    ctx.reply("✅ Dependencies berhasil diinstall!");
  } catch (error) {
    isInstallingDependencies = false;
    console.error("Error in install_deps:", error);
    ctx.reply(`❌ Gagal install dependencies:\n${error.message}`);
  }
  
  ctx.answerCbQuery();
});

// Bot Stats Callback
bot.action("bot_stats", async (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  try {
    const stats = await db.getBotStats();
    ctx.reply(
      `📊 **Bot Statistics**\n\n` +
      `Total Users: ${stats.total_users}\n` +
      `Total Builds: ${stats.total_builds}\n` +
      `Success: ${stats.success_builds}\n` +
      `Failed: ${stats.failed_builds}\n` +
      `Queue Length: ${queue.getQueueLength()}/100`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error in bot_stats:", error);
    ctx.reply("❌ Error mengambil bot stats");
  }
  
  ctx.answerCbQuery();
});

// User Management Callback
bot.action("user_management", (ctx) => {
  if (ctx.from.id !== config.OWNER_ID) {
    ctx.answerCbQuery("Akses ditolak!", true);
    return;
  }
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback("➕ Add Credit", "add_credit_menu")],
    [Markup.button.callback("➖ Remove Credit", "remove_credit_menu")],
    [Markup.button.callback("🔄 Reset Credit", "reset_credit_menu")],
    [Markup.button.callback("🔙 Back", "owner_menu")],
  ]);
  
  ctx.reply(
    "👥 **User Management**\n\n" +
    "Pilih aksi untuk manage credit user:",
    {
      parse_mode: "Markdown",
      reply_markup: buttons.reply_markup,
    }
  );
  
  ctx.answerCbQuery();
});

// ===== TEXT INPUT HANDLER =====

bot.on("text", async (ctx) => {
  const userId = ctx.from.id;
  
  // Handle VPS IP input
  if (userSessions[userId]?.awaitingVpsIp && userId === config.OWNER_ID) {
    const vpsIp = ctx.message.text.trim();
    
    // Validate IP format (simple check)
    if (vpsIp.length < 7) {
      ctx.reply("❌ Format IP tidak valid! Coba lagi dengan format yang benar");
      return;
    }
    
    try {
      await db.setVPSConfig(vpsIp);
      ctx.reply(`✅ VPS IP berhasil diset ke: ${vpsIp}`);
      userSessions[userId].awaitingVpsIp = false;
    } catch (error) {
      console.error("Error setting VPS IP:", error);
      ctx.reply(`❌ Gagal mengset VPS IP:\n${error.message}`);
    }
  }
});

// ===== FILE UPLOAD =====
bot.on("document", async (ctx) => {
  const userId = ctx.from.id;
  const file = ctx.message.document;
  
  try {
    // Check VPS Connection
    const vpsConfig = await db.getVPSConfig();
    if (!vpsConfig || !vpsConfig.host) {
      ctx.reply("⚠️ SSH Not Connect, Tidak Bisa Build Sementara Waktu");
      return;
    }
    
    // Check Credit
    const user = await db.getUserData(userId);
    if (!user || user.credit <= 0) {
      ctx.reply("❌ Kredit Anda tidak cukup! Hubungi owner untuk menambah kredit.");
      return;
    }
    
    // Check file type
    if (!file.file_name.endsWith(".zip")) {
      ctx.reply("❌ File harus berformat .zip!");
      return;
    }
    
    ctx.reply("✅ File diterima! Antrian build: " + (queue.getQueueLength() + 1));
    
    // Add to queue
    const buildId = queue.addBuild({
      userId,
      fileId: file.file_id,
      fileName: file.file_name,
    });
    
    ctx.reply(`📋 Build ID: ${buildId}\nStatus: Menunggu antrian...`);
  } catch (error) {
    console.error("Error in document handler:", error);
    ctx.reply("❌ Error memproses file");
  }
});

// ===== ERROR HANDLING =====
bot.catch((err, ctx) => {
  console.error("❌ Bot Error:", err);
});

// ===== GRACEFUL SHUTDOWN =====
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));

// ===== START BOT =====
startBot();